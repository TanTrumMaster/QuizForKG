package com.example.quizforkgversion3;

import android.app.Activity;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class testActivity  extends Activity {

    public static final String EXTRA_SCORE = "extraScore";


    private static final String KEY_SCORE = "keyScore";
    private static final String KEY_QUESTION_COUNT = "keyQuestionCount";
    private static final String KEY_MILLIS_LEFT = "keyMillsLeft";
    private static final String KEY_ANSWERED = "keyAnswered";
    private static final String KEY_QUESTION_LIST = "keuQuestionList";

    private TextView textViewQuestion;
    private TextView textViewScore;
    private TextView textViewQuestionCount;

    private TextView textViewCategory;
    private TextView textViewDifficulty;

    private ImageView imageView;
    private RadioGroup rbGroup;
    private RadioButton rb1;
    private RadioButton rb2;
    private RadioButton rb3;
    private Button buttonConfirmNext;

    private ColorStateList textColorDefaultRb;
    private ColorStateList textColorDefaultCd;


    private long timeLeftInMillis;

    private ArrayList<Question> questionList;
    private int questionCounter;
    private int questionCounterTotal;
    private Question currentQuestion;

    private int score;
    private boolean answered;

    private AdView mAdView;

    private long backPressedTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.quiz_test);

        mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);

        textViewQuestion = findViewById(R.id.tvQuestion);
        textViewScore = findViewById(R.id.tvScore);
        textViewQuestionCount = findViewById(R.id.tvQuestionCount);



        textViewCategory = findViewById(R.id.tvCategory);
        textViewDifficulty = findViewById(R.id.tvDifficulty);

        imageView = findViewById(R.id.imageView);

        rbGroup = findViewById(R.id.radio_group);
        rb1 = findViewById(R.id.radio_button1);
        rb2 = findViewById(R.id.radio_button2);
        rb3 = findViewById(R.id.radio_button3);
        buttonConfirmNext = findViewById(R.id.btnConfirm);

        textColorDefaultRb = rb1.getTextColors();


        Intent intent = getIntent();
        int categoryID = intent.getIntExtra(MainActivity.EXTRA_CATEGORY_ID, 0);
        String categoryName = intent.getStringExtra(MainActivity.EXTRA_CATEGORY_NAME);
        String difficulty = intent.getStringExtra(MainActivity.EXTRA_DIFFICULTY);

        textViewCategory.setText("Category: " + categoryName);
        textViewDifficulty.setText("Difficulty: " + difficulty);

        if (savedInstanceState == null) {
            QuizDbHelper dbHelper = QuizDbHelper.getInstance(this);
            questionList = dbHelper.getQuestions(categoryID, difficulty);
            questionCounterTotal = questionList.size();
            Collections.shuffle(questionList);

            showNextQuestion();
        } else {
            questionList = savedInstanceState.getParcelableArrayList(KEY_QUESTION_LIST);
            if (questionList == null) {
                finish();
            }
            questionCounterTotal = questionList.size();
            questionCounter = savedInstanceState.getInt(KEY_QUESTION_COUNT);
            currentQuestion = questionList.get(questionCounter - 1);
            score = savedInstanceState.getInt(KEY_SCORE);
            timeLeftInMillis = savedInstanceState.getLong(KEY_MILLIS_LEFT);
            answered = savedInstanceState.getBoolean(KEY_ANSWERED);


        }

        buttonConfirmNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!answered) {
                    if (rb1.isChecked() || rb2.isChecked() || rb3.isChecked()) {
                        checkAnswer();
                    } else {
                        Toast.makeText(testActivity.this, "Please select an answer", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    showNextQuestion();
                }
            }
        });
        AdView adView = new AdView(this);
        adView.setAdSize(AdSize.BANNER);
        adView.setAdUnitId("ca-app-pub-3940256099942544/6300978111");
// TODO: Add adView to your view hierarchy.
        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });
    }

    private void showNextQuestion() {
        rb1.setTextColor(textColorDefaultRb);
        rb2.setTextColor(textColorDefaultRb);
        rb3.setTextColor(textColorDefaultRb);
        rbGroup.clearCheck();

        if (questionCounter < questionCounterTotal) {
            currentQuestion = questionList.get(questionCounter);
            textViewQuestion.setText("Select the correct option");
            rb1.setText(currentQuestion.getOption1());
            rb2.setText(currentQuestion.getOption2());
            rb3.setText(currentQuestion.getOption3());

            questionCounter++;
            textViewQuestionCount.setText("Question: " + questionCounter + " / " + questionCounterTotal);
            answered = false;
            buttonConfirmNext.setText("Confirm");
            updateimage();


        } else {
            finishQuiz();
        }
    }
    private void updateimage() {

        Scanner scanner = new Scanner(String.valueOf(currentQuestion.getQuestion()));
        String s = scanner.nextLine();
        System.out.println(s);

        int b = Integer.parseInt(String.valueOf(s));

        //animals
        if(b == 1){
            imageView.setImageResource(R.drawable.a1);
            System.out.println("a"+b+" deployed");
        }if(b == 2){
            imageView.setImageResource(R.drawable.a2);
            System.out.println("a"+b+" deployed");
        }if(b == 3){
            imageView.setImageResource(R.drawable.a3);
            System.out.println("a"+b+" deployed");
        }if(b == 4){
            imageView.setImageResource(R.drawable.a4);
            System.out.println("a"+b+" deployed");
        }if(b == 5){
            imageView.setImageResource(R.drawable.a5);
            System.out.println("a"+b+" deployed");
        }if(b == 6){
            imageView.setImageResource(R.drawable.a6);
            System.out.println("a"+b+" deployed");
        }if(b == 7){
            imageView.setImageResource(R.drawable.a7);
            System.out.println("a"+b+" deployed");
        }if(b == 8){
            imageView.setImageResource(R.drawable.a8);
            System.out.println("a"+b+" deployed");
        }if(b == 9){
            imageView.setImageResource(R.drawable.a9);
            System.out.println("a"+b+" deployed");
        }if(b == 10){
            imageView.setImageResource(R.drawable.a10);
            System.out.println("a"+b+" deployed");
        }if(b == 11){
            imageView.setImageResource(R.drawable.a11);
            System.out.println("a"+b+" deployed");
        }if(b == 12){
            imageView.setImageResource(R.drawable.a12);
            System.out.println("a"+b+" deployed");
        }if(b == 13){
            imageView.setImageResource(R.drawable.a13);
            System.out.println("a"+b+" deployed");
        }if(b == 14){
            imageView.setImageResource(R.drawable.a14);
            System.out.println("a"+b+" deployed");
        }if(b == 15){
            imageView.setImageResource(R.drawable.a15);
            System.out.println("a"+b+" deployed");
        }if(b == 16){
            imageView.setImageResource(R.drawable.a16);
            System.out.println("a"+b+" deployed");
        }if(b == 17){
            imageView.setImageResource(R.drawable.a17);
            System.out.println("a"+b+" deployed");
        }if(b == 18){
            imageView.setImageResource(R.drawable.a18);
            System.out.println("a"+b+" deployed");
        }if(b == 19){
            imageView.setImageResource(R.drawable.a19);
            System.out.println("a"+b+" deployed");
        }
        //birds
        if(b == 111){
            imageView.setImageResource(R.drawable.b11);
            System.out.println("b"+b+" deployed");
        }if(b == 112){
            imageView.setImageResource(R.drawable.b21);
            System.out.println("b"+b+" deployed");
        }if(b == 113){
            imageView.setImageResource(R.drawable.b31);
            System.out.println("b"+b+" deployed");
        }if(b == 114){
            imageView.setImageResource(R.drawable.b41);
            System.out.println("b"+b+" deployed");
        }if(b == 115){
            imageView.setImageResource(R.drawable.b51);
            System.out.println("b"+b+" deployed");
        }if(b == 116){
            imageView.setImageResource(R.drawable.b61);
            System.out.println("b"+b+" deployed");
        }if(b == 117){
            imageView.setImageResource(R.drawable.b71);
            System.out.println("b"+b+" deployed");
        }if(b == 118){
            imageView.setImageResource(R.drawable.b81);
            System.out.println("b"+b+" deployed");
        }if(b == 119){
            imageView.setImageResource(R.drawable.b91);
            System.out.println("b"+b+" deployed");
        }if(b == 110){
            imageView.setImageResource(R.drawable.b101);
            System.out.println("b"+b+" deployed");
        }if(b == 11112){
            imageView.setImageResource(R.drawable.b111);
            System.out.println("b"+b+" deployed");
        }
        //colours
        if(b == 221){
            imageView.setImageResource(R.drawable.c1);
            System.out.println("c"+b+" deployed");
        }if(b == 222){
            imageView.setImageResource(R.drawable.c2);
            System.out.println("c"+b+" deployed");
        }if(b == 223){
            imageView.setImageResource(R.drawable.c3);
            System.out.println("c"+b+" deployed");
        }if(b == 224){
            imageView.setImageResource(R.drawable.c4);
            System.out.println("c"+b+" deployed");
        }if(b == 225){
            imageView.setImageResource(R.drawable.c7);
            System.out.println("c"+b+" deployed");
        }if(b == 226){
            imageView.setImageResource(R.drawable.c6);
            System.out.println("c"+b+" deployed");
        }if(b == 227){
            imageView.setImageResource(R.drawable.c5);
            System.out.println("c"+b+" deployed");
        }if(b == 228){
            imageView.setImageResource(R.drawable.c8);
            System.out.println("c"+b+" deployed");
        }if(b == 220){
            imageView.setImageResource(R.drawable.c10);
            System.out.println("c"+b+" deployed");
        }
        //flowers
        if(b == 301){
            imageView.setImageResource(R.drawable.f11);
            System.out.println("f"+b+" deployed");
        }if(b == 302){
            imageView.setImageResource(R.drawable.f21);
            System.out.println("f"+b+" deployed");
        }if(b == 303){
            imageView.setImageResource(R.drawable.f31);
            System.out.println("f"+b+" deployed");
        }if(b == 304){
            imageView.setImageResource(R.drawable.f41);
            System.out.println("f"+b+" deployed");
        }if(b == 305){
            imageView.setImageResource(R.drawable.f51);
            System.out.println("f"+b+" deployed");
        }if(b == 306){
            imageView.setImageResource(R.drawable.f61);
            System.out.println("f"+b+" deployed");
        }
        //fruits
        if(b == 401){
            imageView.setImageResource(R.drawable.fr11);
            System.out.println("fr"+b+" deployed");
        }if(b == 402){
            imageView.setImageResource(R.drawable.fr21);
            System.out.println("fr"+b+" deployed");
        }if(b == 403){
            imageView.setImageResource(R.drawable.fr31);
            System.out.println("fr"+b+" deployed");
        }if(b == 404){
            imageView.setImageResource(R.drawable.fr41);
            System.out.println("fr"+b+" deployed");
        }if(b == 405){
            imageView.setImageResource(R.drawable.fr51);
            System.out.println("fr"+b+" deployed");
        }if(b == 406){
            imageView.setImageResource(R.drawable.fr61);
            System.out.println("fr"+b+" deployed");
        }if(b == 407){
            imageView.setImageResource(R.drawable.fr71);
            System.out.println("fr"+b+" deployed");
        }
        //insects
        if(b == 501){
            imageView.setImageResource(R.drawable.i11);
            System.out.println("i"+b+" deployed");
        }if(b == 502){
            imageView.setImageResource(R.drawable.i21);
            System.out.println("i"+b+" deployed");
        }if(b == 503){
            imageView.setImageResource(R.drawable.i31);
            System.out.println("i"+b+" deployed");
        }if(b == 504){
            imageView.setImageResource(R.drawable.i41);
            System.out.println("i"+b+" deployed");
        }if(b == 505){
            imageView.setImageResource(R.drawable.i51);
            System.out.println("i"+b+" deployed");
        }if(b == 506){
            imageView.setImageResource(R.drawable.i61);
            System.out.println("i"+b+" deployed");
        }if(b == 507){
            imageView.setImageResource(R.drawable.i71);
            System.out.println("i"+b+" deployed");
        }
        //objects
        if(b == 601){
            imageView.setImageResource(R.drawable.o11);
            System.out.println("o"+b+" deployed");
        }if(b == 602){
            imageView.setImageResource(R.drawable.o21);
            System.out.println("o"+b+" deployed");
        }if(b == 603){
            imageView.setImageResource(R.drawable.o31);
            System.out.println("o"+b+" deployed");
        }if(b == 604){
            imageView.setImageResource(R.drawable.o41);
            System.out.println("o"+b+" deployed");
        }if(b == 605){
            imageView.setImageResource(R.drawable.o51);
            System.out.println("o"+b+" deployed");
        }if(b == 606){
            imageView.setImageResource(R.drawable.o61);
            System.out.println("o"+b+" deployed");
        }if(b == 607){
            imageView.setImageResource(R.drawable.o71);
            System.out.println("o"+b+" deployed");
        }if(b == 608){
            imageView.setImageResource(R.drawable.o81);
            System.out.println("o"+b+" deployed");
        }if(b == 609){
            imageView.setImageResource(R.drawable.o91);
            System.out.println("o"+b+" deployed");
        }if(b == 610){
            imageView.setImageResource(R.drawable.o10);
            System.out.println("o"+b+" deployed");
        }
        //shapes
        if(b == 701){
            imageView.setImageResource(R.drawable.s1);
            System.out.println("s"+b+" deployed");
        }if(b == 702){
            imageView.setImageResource(R.drawable.s2);
            System.out.println("s"+b+" deployed");
        }if(b == 703){
            imageView.setImageResource(R.drawable.s3);
            System.out.println("s"+b+" deployed");
        }if(b == 704){
            imageView.setImageResource(R.drawable.s4);
            System.out.println("s"+b+" deployed");
        }if(b == 705){
            imageView.setImageResource(R.drawable.s5);
            System.out.println("s"+b+" deployed");
        }if(b == 706){
            imageView.setImageResource(R.drawable.s6);
            System.out.println("s"+b+" deployed");
        }if(b == 707){
            imageView.setImageResource(R.drawable.s7);
            System.out.println("s"+b+" deployed");
        }if(b == 708){
            imageView.setImageResource(R.drawable.s8);
            System.out.println("s"+b+" deployed");
        }if(b == 709){
            imageView.setImageResource(R.drawable.s9);
            System.out.println("s"+b+" deployed");
        }if(b == 710){
            imageView.setImageResource(R.drawable.s10);
            System.out.println("s"+b+" deployed");
        }
        //vehicles
        if(b == 801){
            imageView.setImageResource(R.drawable.v11);
            System.out.println("s"+b+" deployed");
        }if(b == 802){
            imageView.setImageResource(R.drawable.v21);
            System.out.println("s"+b+" deployed");
        }if(b == 803){
            imageView.setImageResource(R.drawable.v31);
            System.out.println("s"+b+" deployed");
        }if(b == 804){
            imageView.setImageResource(R.drawable.v41);
            System.out.println("s"+b+" deployed");
        }if(b == 805){
            imageView.setImageResource(R.drawable.v51);
            System.out.println("s"+b+" deployed");
        }if(b == 806){
            imageView.setImageResource(R.drawable.v61);
            System.out.println("s"+b+" deployed");
        }if(b == 807){
            imageView.setImageResource(R.drawable.v71);
            System.out.println("s"+b+" deployed");
        }if(b == 808){
            imageView.setImageResource(R.drawable.v81);
            System.out.println("s"+b+" deployed");
        }
    }


    private void checkAnswer() {
        answered = true;

        RadioButton rbSelected = findViewById(rbGroup.getCheckedRadioButtonId());
        int answerNr = rbGroup.indexOfChild(rbSelected) + 1;
        if (answerNr == currentQuestion.getAnswerNr()) {
            score++;

        }
        showSolution();
    }

    private void showSolution() {


        switch (currentQuestion.getAnswerNr()) {
          }
        if (questionCounter < questionCounterTotal) {
            buttonConfirmNext.setText("Next");
        } else {
            buttonConfirmNext.setText("Finish");
        }
    }

    private void finishQuiz() {
        Intent resultIntent = new Intent();
        resultIntent.putExtra(EXTRA_SCORE, score);
        setResult(RESULT_OK, resultIntent);
        finish();
    }

    @Override
    public void onBackPressed() {
        if (backPressedTime + 2000 > System.currentTimeMillis()) {
            finishQuiz();
        } else {
            Toast.makeText(this, "Press back again to finish", Toast.LENGTH_SHORT).show();
        }
        backPressedTime = System.currentTimeMillis();
    }



    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(KEY_SCORE, score);
        outState.putInt(KEY_QUESTION_COUNT, questionCounter);
        outState.putLong(KEY_MILLIS_LEFT, timeLeftInMillis);
        outState.putBoolean(KEY_ANSWERED, answered);
        outState.putParcelableArrayList(KEY_QUESTION_LIST, questionList);

    }
}
