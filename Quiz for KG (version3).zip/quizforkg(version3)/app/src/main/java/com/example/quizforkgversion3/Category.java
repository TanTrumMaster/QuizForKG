package com.example.quizforkgversion3;

public class Category  {
    public static final int animals = 1;
    public static final int birds = 2;
    public static int colours = 3;
    public static int flowers = 4;
    public static int fruits = 5;
    public static int insects = 6;
    public static int objects = 7;
    public static int shapes = 8;
    public static int vehicles = 9;

    private int id;
    private String name;

    public Category() {
    }

    public Category(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return getName();
    }
}

