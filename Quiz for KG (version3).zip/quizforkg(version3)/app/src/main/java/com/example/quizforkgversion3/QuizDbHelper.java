package com.example.quizforkgversion3;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.quizforkgversion3.QuizContract.*;

import java.util.ArrayList;
import java.util.List;

public class QuizDbHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "AwesomeQuiz.db";
    public static final int DATABASE_VERSION = 9;

    private static QuizDbHelper instance;

    private SQLiteDatabase db;

    public QuizDbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    public static synchronized QuizDbHelper getInstance(Context context) {
        if (instance == null) {
            instance = new QuizDbHelper(context.getApplicationContext());
        }
        return instance;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        this.db = db;

        final String SQL_CREATE_CATEGORY_TABLE = "CREATE TABLE " +
                CategoriesTable.TABLE_NAME + " ( " +
                CategoriesTable._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                CategoriesTable.COLUMN_NAME + " TEXT " + ")";

        final String SQL_CREATE_QUESTION_TABLE = "CREATE TABLE " +
                QuestionTable.TABLE_NAME + " ( " +
                QuestionTable._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                QuestionTable.COLUMN_QUESTION + " TEXT, " +
                QuestionTable.COLUMN_OPTION1 + " TEXT, " +
                QuestionTable.COLUMN_OPTION2 + " TEXT, " +
                QuestionTable.COLUMN_OPTION3 + " TEXT, " +
                QuestionTable.COLUMN_ANSWER_NR + " INTEGER, " +
                QuestionTable.COLUMN_DIFFICULTY + " TEXT," +
                QuestionTable.COLUMN_CATEGORY_ID + " INTEGER, " +
                "FOREIGN KEY(" + QuestionTable.COLUMN_CATEGORY_ID + ") REFERENCES " +
                CategoriesTable.TABLE_NAME + "(" + CategoriesTable._ID + ")" + "ON DELETE CASCADE" + ")";

        db.execSQL(SQL_CREATE_CATEGORY_TABLE);
        db.execSQL(SQL_CREATE_QUESTION_TABLE);
        fillCategoriesTable();
        fillQuestionTable();
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + CategoriesTable.TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + QuestionTable.TABLE_NAME);
        onCreate(db);
    }

    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
    }

    private void fillCategoriesTable() {
        com.example.quizforkgversion3.Category c1 = new com.example.quizforkgversion3.Category("animals");
        insertCategory(c1);

        com.example.quizforkgversion3.Category c2 = new com.example.quizforkgversion3.Category("birds");
        insertCategory(c2);

        com.example.quizforkgversion3.Category c3 = new com.example.quizforkgversion3.Category("colours");
        insertCategory(c3);

        com.example.quizforkgversion3.Category c4 = new com.example.quizforkgversion3.Category("flowers");
        insertCategory(c4);

        com.example.quizforkgversion3.Category c5 = new com.example.quizforkgversion3.Category("fruits");
        insertCategory(c5);

        com.example.quizforkgversion3.Category c6 = new com.example.quizforkgversion3.Category("insects");
        insertCategory(c6);

        com.example.quizforkgversion3.Category c7 = new com.example.quizforkgversion3.Category("objects");
        insertCategory(c7);

        com.example.quizforkgversion3.Category c8 = new com.example.quizforkgversion3.Category("shapes");
        insertCategory(c8);

        com.example.quizforkgversion3.Category c9 = new com.example.quizforkgversion3.Category("vehicles");
        insertCategory(c9);
    }

    private void insertCategory(com.example.quizforkgversion3.Category category) {
        ContentValues cv = new ContentValues();
        cv.put(CategoriesTable.COLUMN_NAME, category.getName());
        db.insert(CategoriesTable.TABLE_NAME, null, cv);
    }

    private void fillQuestionTable() {

        // animals
        com.example.quizforkgversion3.Question q1 = new com.example.quizforkgversion3.Question("1","Donkey", "Lion ", "Horse",  3, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , com.example.quizforkgversion3.Category.animals);
        insertQuestion(q1);
        com.example.quizforkgversion3.Question q2 = new com.example.quizforkgversion3.Question("2", "Cat", "Dog", "Tiger", 1, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , com.example.quizforkgversion3.Category.animals);
        insertQuestion(q2);
        com.example.quizforkgversion3.Question q3 = new com.example.quizforkgversion3.Question("3","Crocodile", "Dog","Elephant", 2, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , com.example.quizforkgversion3.Category.animals);
        insertQuestion(q3);
        com.example.quizforkgversion3.Question q4 = new com.example.quizforkgversion3.Question("4", "Donkey", "Horse", "Cow", 1, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , com.example.quizforkgversion3.Category.animals);
        insertQuestion(q4);
        com.example.quizforkgversion3.Question q5 = new com.example.quizforkgversion3.Question("5","Cat","Lion","Dog", 2, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , com.example.quizforkgversion3.Category.animals);
        insertQuestion(q5);
        com.example.quizforkgversion3.Question q6 = new com.example.quizforkgversion3.Question("6","Tiger","Lion","Monkey", 1, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , com.example.quizforkgversion3.Category.animals);
        insertQuestion(q6);
        com.example.quizforkgversion3.Question q7 = new com.example.quizforkgversion3.Question("7","Fox","Snake","Crocodile", 3, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , com.example.quizforkgversion3.Category.animals);
        insertQuestion(q7);
        com.example.quizforkgversion3.Question q8 = new com.example.quizforkgversion3.Question("8","Hippo or hippopotamus","Zebra","Dog", 1, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , com.example.quizforkgversion3.Category.animals);
        insertQuestion(q8);
        com.example.quizforkgversion3.Question q9 = new com.example.quizforkgversion3.Question("9","Horse","Cow","Elephant", 3, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , com.example.quizforkgversion3.Category.animals);
        insertQuestion(q9);
        com.example.quizforkgversion3.Question q10 = new com.example.quizforkgversion3.Question("10","Hippo or hippopotamus","Crab","Rat", 2, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , com.example.quizforkgversion3.Category.animals);
        insertQuestion(q10);
        com.example.quizforkgversion3.Question q11 = new com.example.quizforkgversion3.Question("11","Monkey","Fox","Cat", 2, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , com.example.quizforkgversion3.Category.animals);
        insertQuestion(q11);
        com.example.quizforkgversion3.Question q12 = new com.example.quizforkgversion3.Question("12","Rat","Lion","Cat", 1, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , com.example.quizforkgversion3.Category.animals);
        insertQuestion(q12);
        com.example.quizforkgversion3.Question q13 = new com.example.quizforkgversion3.Question("13","Crocodile","Zebra","Snake", 2, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , com.example.quizforkgversion3.Category.animals);
        insertQuestion(q13);
        com.example.quizforkgversion3.Question q14 = new com.example.quizforkgversion3.Question("14","Snake","Donkey","Horse", 1, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , com.example.quizforkgversion3.Category.animals);
        insertQuestion(q14);
        com.example.quizforkgversion3.Question q15 = new com.example.quizforkgversion3.Question("15","Cat","Monkey","Rhino", 3, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , com.example.quizforkgversion3.Category.animals);
        insertQuestion(q15);
        com.example.quizforkgversion3.Question q16 = new com.example.quizforkgversion3.Question("16","Monkey","Bull","Cow", 3, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , com.example.quizforkgversion3.Category.animals);
        insertQuestion(q16);
        com.example.quizforkgversion3.Question q17 = new com.example.quizforkgversion3.Question("17","Cat","Bull","Rabbit", 2, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , com.example.quizforkgversion3.Category.animals);
        insertQuestion(q17);
        com.example.quizforkgversion3.Question q18 = new com.example.quizforkgversion3.Question("18","Dog","Zebra","Rabbit", 3, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , com.example.quizforkgversion3.Category.animals);
        insertQuestion(q18);
        com.example.quizforkgversion3.Question q19 = new com.example.quizforkgversion3.Question("19","Monkey","Lion","Dog", 1, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , com.example.quizforkgversion3.Category.animals);
        insertQuestion(q19);

        //birds
        com.example.quizforkgversion3.Question q111 = new com.example.quizforkgversion3.Question("111","Pigeon","Peacock","Crow", 1, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.birds);
        insertQuestion(q111);
        com.example.quizforkgversion3.Question q112 = new com.example.quizforkgversion3.Question("112","Crow","Wood Pecker","Sparrow", 1, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.birds);
        insertQuestion(q112);
        com.example.quizforkgversion3.Question q113 = new com.example.quizforkgversion3.Question("113","Owl","Hen","Swan", 3, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.birds);
        insertQuestion(q113);
        com.example.quizforkgversion3.Question q114 = new com.example.quizforkgversion3.Question("114","Ostrich","Swan","Crow",3, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.birds);
        insertQuestion(q114);
        com.example.quizforkgversion3.Question q115 = new com.example.quizforkgversion3.Question("115","Hen","Parrot","Sparrow", 2, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.birds);
        insertQuestion(q115);
        com.example.quizforkgversion3.Question q116 = new com.example.quizforkgversion3.Question("116","Pigeon","Wood Pecker","Owl", 2, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.birds);
        insertQuestion(q116);
        com.example.quizforkgversion3.Question q117 = new com.example.quizforkgversion3.Question("117","King Fisher","Peacock","Ostrich", 1, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.birds);
        insertQuestion(q117);
        com.example.quizforkgversion3.Question q118 = new com.example.quizforkgversion3.Question("118","Wood Pecker","Sparrow","Hen", 2, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.birds);
        insertQuestion(q118);
        com.example.quizforkgversion3.Question q119 = new com.example.quizforkgversion3.Question("119","Hen","Pegion","Crow", 1, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.birds);
        insertQuestion(q119);
        com.example.quizforkgversion3.Question q110 = new com.example.quizforkgversion3.Question("110","King Fisher","Peacock","Swan", 2, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.birds);
        insertQuestion(q110);
        com.example.quizforkgversion3.Question q11112 = new com.example.quizforkgversion3.Question("11112","Pigeon","Owl","Crow", 2, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.birds);
        insertQuestion(q11112);

        //colours
        com.example.quizforkgversion3.Question q221 = new com.example.quizforkgversion3.Question("221","Red","Black","Green", 2, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.colours);
        insertQuestion(q221);
        com.example.quizforkgversion3.Question q222 = new com.example.quizforkgversion3.Question("222","Yellow","Brown","Blue", 3, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.colours);
        insertQuestion(q222);
        com.example.quizforkgversion3.Question q223 = new com.example.quizforkgversion3.Question("223","Brown","Blue","Green", 1, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.colours);
        insertQuestion(q223);
        com.example.quizforkgversion3.Question q224 = new com.example.quizforkgversion3.Question("224","Yellow","Grey","Green", 3, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.colours);
        insertQuestion(q224);
        com.example.quizforkgversion3.Question q225 = new com.example.quizforkgversion3.Question("225","White","Pink","Black", 2, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.colours);
        insertQuestion(q225);
        com.example.quizforkgversion3.Question q226 = new com.example.quizforkgversion3.Question("226", "Pink","Red","Orange", 3,com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.colours);
        insertQuestion(q226);
        com.example.quizforkgversion3.Question q227 = new com.example.quizforkgversion3.Question("227","White","Red","Yellow", 1, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.colours);
        insertQuestion(q227);
        com.example.quizforkgversion3.Question q228 = new com.example.quizforkgversion3.Question("228","White","Black","Red", 3, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.colours);
        insertQuestion(q228);
        com.example.quizforkgversion3.Question q229 = new com.example.quizforkgversion3.Question("220","Yellow","Blue","Brown", 1, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.colours);
        insertQuestion(q229);

        //flowers
        com.example.quizforkgversion3.Question q301 = new com.example.quizforkgversion3.Question("301","Sunflower","Rose","Lotus", 1, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.flowers);
        insertQuestion(q301);
        com.example.quizforkgversion3.Question q302 = new com.example.quizforkgversion3.Question("302","Shoe Flower","Lotus","Lily", 3, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.flowers);
        insertQuestion(q302);
        com.example.quizforkgversion3.Question q303 = new com.example.quizforkgversion3.Question("303","Mogra","Lotus","Rose", 2, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.flowers);
        insertQuestion(q303);
        com.example.quizforkgversion3.Question q304 = new com.example.quizforkgversion3.Question("304","Sunflower","Rose","Shoe Flower", 2, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.flowers);
        insertQuestion(q304);
        com.example.quizforkgversion3.Question q305 = new com.example.quizforkgversion3.Question("305","Lily","Rose","Shoe Flower", 3, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.flowers);
        insertQuestion(q305);
        com.example.quizforkgversion3.Question q306 = new com.example.quizforkgversion3.Question("306","Mogra","Rose","Lotus", 1, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.flowers);
        insertQuestion(q306);

        //fruits
        com.example.quizforkgversion3.Question q401 = new com.example.quizforkgversion3.Question("401","Banana","Apple","Water Melon", 1, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.fruits);
        insertQuestion(q401);
        com.example.quizforkgversion3.Question q402 = new com.example.quizforkgversion3.Question("402","Custard Apple","Orange","Apple", 2, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.fruits);
        insertQuestion(q402);
        com.example.quizforkgversion3.Question q403 = new com.example.quizforkgversion3.Question("403","Mango","Water Melon","Grapes", 3, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.fruits);
        insertQuestion(q403);
        com.example.quizforkgversion3.Question q404 = new com.example.quizforkgversion3.Question("404","Banana","Custard Apple","Mango", 3, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.fruits);
        insertQuestion(q404);
        com.example.quizforkgversion3.Question q405 = new com.example.quizforkgversion3.Question("405","Custard Apple","Apple","Grapes", 1, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.fruits);
        insertQuestion(q405);
        com.example.quizforkgversion3.Question q406 = new com.example.quizforkgversion3.Question("406","Water Melon","Apple","Mango", 2, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.fruits);
        insertQuestion(q406);
        com.example.quizforkgversion3.Question q407 = new com.example.quizforkgversion3.Question("407","Water Melon","Apple","Orange", 1, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.fruits);
        insertQuestion(q407);

        //insects
        com.example.quizforkgversion3.Question q501 = new com.example.quizforkgversion3.Question("501","Grass Hopper","Earth Worm","Butter Fly", 2, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.insects);
        insertQuestion(q501);
        com.example.quizforkgversion3.Question q502 = new com.example.quizforkgversion3.Question("502","Earth Worm","Grass Hopper","Caterpillar", 2, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.insects);
        insertQuestion(q502);
        com.example.quizforkgversion3.Question q503 = new com.example.quizforkgversion3.Question("503","Mosquito","Ant","Cockroach", 1, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.insects);
        insertQuestion(q503);
        com.example.quizforkgversion3.Question q504 = new com.example.quizforkgversion3.Question("504","Caterpillar","Grass Hopper","Butter Fly", 3, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.insects);
        insertQuestion(q504);
        com.example.quizforkgversion3.Question q505 = new com.example.quizforkgversion3.Question("505","Caterpillar","Ant","Earth Worm", 1, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.insects);
        insertQuestion(q505);
        com.example.quizforkgversion3.Question q506 = new com.example.quizforkgversion3.Question("506","Earth Worm","Mosquito","Cockroach", 3, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.insects);
        insertQuestion(q506);
        com.example.quizforkgversion3.Question q507 = new com.example.quizforkgversion3.Question("507","Ant","Grass Hopper","Butter Fly", 1, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.insects);
        insertQuestion(q507);

        //objects
        com.example.quizforkgversion3.Question q601 = new com.example.quizforkgversion3.Question("601","Table","Flower","Fruit", 3, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.objects);
        insertQuestion(q601);
        com.example.quizforkgversion3.Question q602 = new com.example.quizforkgversion3.Question("602","Ball","Chair","Flower", 3, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.objects);
        insertQuestion(q602);
        com.example.quizforkgversion3.Question q603 = new com.example.quizforkgversion3.Question("603","Pen","Bottle","Fruit", 2, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.objects);
        insertQuestion(q603);
        com.example.quizforkgversion3.Question q604 = new com.example.quizforkgversion3.Question("604","Eraser","Fruit","Table", 3, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.objects);
        insertQuestion(q604);
        com.example.quizforkgversion3.Question q605 = new com.example.quizforkgversion3.Question("605","Table","Chair","Fruit", 2, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.objects);
        insertQuestion(q605);
        com.example.quizforkgversion3.Question q606 = new com.example.quizforkgversion3.Question("606","Ball","Pencil","Bed", 1, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.objects);
        insertQuestion(q606);
        com.example.quizforkgversion3.Question q607 = new com.example.quizforkgversion3.Question("607","Pen","Pencil","Fruit", 1, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.objects);
        insertQuestion(q607);
        com.example.quizforkgversion3.Question q608 = new com.example.quizforkgversion3.Question("608","Table","Fruit","Pencil", 3, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.objects);
        insertQuestion(q608);
        com.example.quizforkgversion3.Question q609 = new com.example.quizforkgversion3.Question("609","Chair","Eraser","Bed", 2, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.objects);
        insertQuestion(q609);
        com.example.quizforkgversion3.Question q610 = new com.example.quizforkgversion3.Question("610","Bed","Bottle","Ball", 1, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.objects);
        insertQuestion(q610);

        //shapes
        com.example.quizforkgversion3.Question q701 = new com.example.quizforkgversion3.Question("701","Circle","Square","Triangle", 1, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.shapes);
        insertQuestion(q701);
        com.example.quizforkgversion3.Question q702 = new com.example.quizforkgversion3.Question("702","Star","Rectangle","Square", 3, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.shapes);
        insertQuestion(q702);
        com.example.quizforkgversion3.Question q703 = new com.example.quizforkgversion3.Question("703","Check Mark or Right Mark","Arrow","Rectangle", 3, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.shapes);
        insertQuestion(q703);
        com.example.quizforkgversion3.Question q704 = new com.example.quizforkgversion3.Question("704","Triangle","Square","Wrong Mark or Cross", 1, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.shapes);
        insertQuestion(q704);
        com.example.quizforkgversion3.Question q705 = new com.example.quizforkgversion3.Question("705","Circle","Diamond","Triangle", 2, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.shapes);
        insertQuestion(q705);
        com.example.quizforkgversion3.Question q706 = new com.example.quizforkgversion3.Question("706","Heart","Square","Arrow Sign", 3, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.shapes);
        insertQuestion(q706);
        com.example.quizforkgversion3.Question q707 = new com.example.quizforkgversion3.Question("707","Star","Circle","Heart", 1, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.shapes);
        insertQuestion(q707);
        com.example.quizforkgversion3.Question q708 = new com.example.quizforkgversion3.Question("708","Circle","Heart","Triangle", 2, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.shapes);
        insertQuestion(q708);
        com.example.quizforkgversion3.Question q709 = new com.example.quizforkgversion3.Question("709","Check Mark or Right Mark","Wrong Mark or Cross","Triangle", 2, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.shapes);
        insertQuestion(q709);
        com.example.quizforkgversion3.Question q710 = new com.example.quizforkgversion3.Question("710","Check Mark or Right Mark","Circle","Wrong Mark or Cross", 1, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.shapes);
        insertQuestion(q710);

        //vehicles
        com.example.quizforkgversion3.Question q801 = new com.example.quizforkgversion3.Question("801","Bike","Ambulance","Train", 2, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.vehicles);
        insertQuestion(q801);
        com.example.quizforkgversion3.Question q802 = new com.example.quizforkgversion3.Question("802","Cycle","Air Plane","Bike", 3, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.vehicles);
        insertQuestion(q802);
        com.example.quizforkgversion3.Question q803 = new com.example.quizforkgversion3.Question("803","Bike","Bus","Fire Truck", 2, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.vehicles);
        insertQuestion(q803);
        com.example.quizforkgversion3.Question q804 = new com.example.quizforkgversion3.Question("804","Air Plane","Ambulance","Train", 1, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.vehicles);
        insertQuestion(q804);
        com.example.quizforkgversion3.Question q805 = new com.example.quizforkgversion3.Question("805","Ambulance","Car","Train", 3, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.vehicles);
        insertQuestion(q805);
        com.example.quizforkgversion3.Question q806 = new com.example.quizforkgversion3.Question("806","Bus","Fire Truck","Cycle", 2, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.vehicles);
        insertQuestion(q806);
        com.example.quizforkgversion3.Question q807 = new com.example.quizforkgversion3.Question("807","Cycle","Car","Bike", 1, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.vehicles);
        insertQuestion(q807);
        com.example.quizforkgversion3.Question q808 = new com.example.quizforkgversion3.Question("808","Car","Ambulance","Air Plane", 1, com.example.quizforkgversion3.Question.DIFFICULTY_EASY , Category.vehicles);
        insertQuestion(q808);
    }

    private void insertQuestion(com.example.quizforkgversion3.Question question) {
        ContentValues cv = new ContentValues();
        cv.put(QuestionTable.COLUMN_QUESTION, question.getQuestion());
        cv.put(QuestionTable.COLUMN_OPTION1, question.getOption1());
        cv.put(QuestionTable.COLUMN_OPTION2, question.getOption2());
        cv.put(QuestionTable.COLUMN_OPTION3, question.getOption3());
        cv.put(QuestionTable.COLUMN_ANSWER_NR, question.getAnswerNr());
        cv.put(QuestionTable.COLUMN_DIFFICULTY, question.getDifficulty());
        cv.put(QuestionTable.COLUMN_CATEGORY_ID, question.getCategoryID());
        db.insert(QuestionTable.TABLE_NAME, null, cv);
    }

    @SuppressLint("Range")
    public List<com.example.quizforkgversion3.Category> getAllCategories() {
        List<com.example.quizforkgversion3.Category> categoryList = new ArrayList<>();
        db = getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + CategoriesTable.TABLE_NAME, null);
        if (cursor.moveToFirst()) {
            do {
                com.example.quizforkgversion3.Category category = new com.example.quizforkgversion3.Category();
                category.setId(cursor.getInt(cursor.getColumnIndex(CategoriesTable._ID)));
                category.setName(cursor.getString(cursor.getColumnIndex(CategoriesTable.COLUMN_NAME)));
                categoryList.add(category);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return categoryList;
    }

    @SuppressLint("Range")
    public ArrayList<com.example.quizforkgversion3.Question> getAllQuestion() {
        ArrayList<com.example.quizforkgversion3.Question> questionList = new ArrayList<>();
        db = getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + QuestionTable.TABLE_NAME, null);

        if (cursor.moveToFirst()) {
            do {
                com.example.quizforkgversion3.Question question = new com.example.quizforkgversion3.Question();
                question.setId(cursor.getInt(cursor.getColumnIndex(QuestionTable._ID)));
                question.setQuestion(cursor.getString(cursor.getColumnIndex(QuestionTable.COLUMN_QUESTION)));
                question.setOption1(cursor.getString(cursor.getColumnIndex(QuestionTable.COLUMN_OPTION1)));
                question.setOption2(cursor.getString(cursor.getColumnIndex(QuestionTable.COLUMN_OPTION2)));
                question.setOption3(cursor.getString(cursor.getColumnIndex(QuestionTable.COLUMN_OPTION3)));
                question.setAnswerNr(cursor.getInt(cursor.getColumnIndex(QuestionTable.COLUMN_ANSWER_NR)));
                question.setDifficulty(cursor.getString(cursor.getColumnIndex(QuestionTable.COLUMN_DIFFICULTY)));
                question.setCategoryID(cursor.getInt(cursor.getColumnIndex(QuestionTable.COLUMN_CATEGORY_ID)));
                questionList.add(question);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return questionList;
    }

    @SuppressLint("Range")
    public ArrayList<com.example.quizforkgversion3.Question> getQuestions(int categoryID, String difficulty) {
        ArrayList<com.example.quizforkgversion3.Question> questionList = new ArrayList<>();
        db = getReadableDatabase();
        String selection = QuestionTable.COLUMN_CATEGORY_ID + "= ? " +
                " AND " + QuestionTable.COLUMN_DIFFICULTY + " = ?";

        String[] selectionArgs = new String[] {String.valueOf(categoryID), difficulty};

        Cursor cursor = db.query(QuestionTable.TABLE_NAME,
                null,
                selection,
                selectionArgs,
                null,null,null);

        if (cursor.moveToFirst()) {
            do {
                com.example.quizforkgversion3.Question question = new com.example.quizforkgversion3.Question();
                question.setId(cursor.getInt(cursor.getColumnIndex(QuestionTable._ID)));
                question.setQuestion(cursor.getString(cursor.getColumnIndex(QuestionTable.COLUMN_QUESTION)));
                question.setOption1(cursor.getString(cursor.getColumnIndex(QuestionTable.COLUMN_OPTION1)));
                question.setOption2(cursor.getString(cursor.getColumnIndex(QuestionTable.COLUMN_OPTION2)));
                question.setOption3(cursor.getString(cursor.getColumnIndex(QuestionTable.COLUMN_OPTION3)));
                question.setAnswerNr(cursor.getInt(cursor.getColumnIndex(QuestionTable.COLUMN_ANSWER_NR)));
                question.setDifficulty(cursor.getString(cursor.getColumnIndex(QuestionTable.COLUMN_DIFFICULTY)));
                question.setCategoryID(cursor.getInt(cursor.getColumnIndex(QuestionTable.COLUMN_CATEGORY_ID)));
                questionList.add(question);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return questionList;
    }
}