package com.example.quizforkgversion3;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;

public class homescreeen extends AppCompatActivity implements View.OnClickListener{

    private AdView mAdView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homescreeen);

        mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);

        Button practice =findViewById(R.id.practice);
        practice.setOnClickListener(this);
        Button test =findViewById(R.id.test);
        test.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.practice:
                Toast.makeText(this,"good luck",Toast.LENGTH_LONG).show();
                practice();
                break;
            case R.id.test:
                Toast.makeText(this,"good luck",Toast.LENGTH_LONG).show();
                test();
                break;

        }
        AdView adView = new AdView(this);
        adView.setAdSize(AdSize.BANNER);
        adView.setAdUnitId("ca-app-pub-3940256099942544/6300978111");
// TODO: Add adView to your view hierarchy.
        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });
    }

    private void practice() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    private void test() {
        Intent intent = new Intent(this,test.class);
        startActivity(intent);
    }
}